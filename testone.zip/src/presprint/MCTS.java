package presprint;
import java.util.*;
import battlecode.common.*;

//trying out a monte carlo tree search for pathfinding along weighted squares, maybe try A* next
public class MCTS extends RobotPlayer{
    public MCTS(){

    }
}