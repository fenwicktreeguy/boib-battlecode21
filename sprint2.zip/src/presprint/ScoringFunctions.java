package presprint;
import battlecode.common.*;
import java.util.*;

public class ScoringFunctions {
    //ideally, these functions should represent local maxima or minima; the needful will be specified
    public static int slanderer_distribute(RobotController rc, int x, int y) throws GameActionException{
        return 0;
    }
    public static int map_swarm(RobotController rc, int x, int y) throws GameActionException{
        return 0;
    }

}